
-- --------------------------------------------------------

--
-- Table structure for table `pli_brands`
--

DROP TABLE IF EXISTS `pli_brands`;
CREATE TABLE `pli_brands` (
  `ID` int(11) NOT NULL,
  `BrandName` varchar(15) NOT NULL,
  `BrandGroup` int(11) NOT NULL,
  `SUP_SUPPLIER_NR` int(11) NOT NULL,
  `BRA_MF_NR` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `pli_brands`
--

TRUNCATE TABLE `pli_brands`;