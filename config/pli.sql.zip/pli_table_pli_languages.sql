
-- --------------------------------------------------------

--
-- Table structure for table `pli_languages`
--

DROP TABLE IF EXISTS `pli_languages`;
CREATE TABLE `pli_languages` (
  `ID` int(11) NOT NULL,
  `ShortName` varchar(2) NOT NULL,
  `Name` varchar(12) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `pli_languages`
--

TRUNCATE TABLE `pli_languages`;