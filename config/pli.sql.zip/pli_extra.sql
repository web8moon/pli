
--
-- Indexes for dumped tables
--

--
-- Indexes for table `pli_brands`
--
ALTER TABLE `pli_brands`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `pli_counties`
--
ALTER TABLE `pli_counties`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Counties_fk0` (`DefaultCurrency`);

--
-- Indexes for table `pli_currencies`
--
ALTER TABLE `pli_currencies`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `pli_languages`
--
ALTER TABLE `pli_languages`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `pli_stockphones`
--
ALTER TABLE `pli_stockphones`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `pli_users`
--
ALTER TABLE `pli_users`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `pli_usersparts`
--
ALTER TABLE `pli_usersparts`
  ADD PRIMARY KEY (`PartID`),
  ADD KEY `UsersParts_fk0` (`StockID`),
  ADD KEY `UsersParts_fk1` (`Brand`);

--
-- Indexes for table `pli_userstoks`
--
ALTER TABLE `pli_userstoks`
  ADD UNIQUE KEY `ID` (`ID`),
  ADD KEY `UserStoks_fk0` (`UserID`),
  ADD KEY `UserStoks_fk1` (`StockCountry`),
  ADD KEY `UserStoks_fk3` (`Currency`),
  ADD KEY `UserStoks_fk4` (`Lang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pli_brands`
--
ALTER TABLE `pli_brands`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pli_counties`
--
ALTER TABLE `pli_counties`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;
--
-- AUTO_INCREMENT for table `pli_currencies`
--
ALTER TABLE `pli_currencies`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pli_languages`
--
ALTER TABLE `pli_languages`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pli_stockphones`
--
ALTER TABLE `pli_stockphones`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `pli_users`
--
ALTER TABLE `pli_users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `pli_usersparts`
--
ALTER TABLE `pli_usersparts`
  MODIFY `PartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79061;
--
-- AUTO_INCREMENT for table `pli_userstoks`
--
ALTER TABLE `pli_userstoks`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `pli_usersparts`
--
ALTER TABLE `pli_usersparts`
  ADD CONSTRAINT `UsersParts_fk0` FOREIGN KEY (`StockID`) REFERENCES `userstoks` (`StockID`),
  ADD CONSTRAINT `UsersParts_fk1` FOREIGN KEY (`Brand`) REFERENCES `brands` (`ID`);
