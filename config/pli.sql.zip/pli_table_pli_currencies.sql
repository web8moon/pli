
-- --------------------------------------------------------

--
-- Table structure for table `pli_currencies`
--

DROP TABLE IF EXISTS `pli_currencies`;
CREATE TABLE `pli_currencies` (
  `ID` int(11) NOT NULL,
  `Name` varchar(3) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16;

--
-- Truncate table before insert `pli_currencies`
--

TRUNCATE TABLE `pli_currencies`;
--
-- Dumping data for table `pli_currencies`
--

INSERT INTO `pli_currencies` (`ID`, `Name`) VALUES
(1, 'ГРН'),
(2, 'РУБ'),
(3, 'EUR'),
(4, 'USD'),
(5, 'Zł');
