
-- --------------------------------------------------------

--
-- Table structure for table `pli_userstoks`
--

DROP TABLE IF EXISTS `pli_userstoks`;
CREATE TABLE `pli_userstoks` (
  `ID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `StockName` varchar(25) NOT NULL,
  `StockCountry` int(11) NOT NULL,
  `StockCity` varchar(20) NOT NULL,
  `StockAdress` varchar(50) NOT NULL,
  `StockEmail` varchar(50) NOT NULL,
  `StockComment` varchar(250) NOT NULL,
  `ShipsInfo` varchar(250) NOT NULL,
  `DateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DateModify` datetime NOT NULL,
  `Currency` int(11) NOT NULL,
  `Lang` int(11) NOT NULL,
  `Active` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16;

--
-- Truncate table before insert `pli_userstoks`
--

TRUNCATE TABLE `pli_userstoks`;
--
-- Dumping data for table `pli_userstoks`
--

INSERT INTO `pli_userstoks` (`ID`, `UserID`, `StockName`, `StockCountry`, `StockCity`, `StockAdress`, `StockEmail`, `StockComment`, `ShipsInfo`, `DateCreated`, `DateModify`, `Currency`, `Lang`, `Active`) VALUES
(8, 20, 'Назва 1', 187, 'Масква', 'Адресс 1, 1', 'mail@mail.ru', '', 'Шипс инфо 1', '2017-11-18 14:11:36', '2017-11-18 16:11:00', 2, 0, 1),
(7, 20, '', 52, '', '', '', '', '', '2017-11-21 16:09:51', '2017-11-21 17:09:51', 3, 0, 0),
(9, 21, '', 0, '', '', '', '', '', '2017-11-06 08:23:37', '0000-00-00 00:00:00', 0, 0, 0),
(10, 22, '', 0, '', '', '', '', '', '2017-11-22 14:11:06', '0000-00-00 00:00:00', 0, 0, 0);
