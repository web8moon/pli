
-- --------------------------------------------------------

--
-- Table structure for table `pli_stockphones`
--

DROP TABLE IF EXISTS `pli_stockphones`;
CREATE TABLE `pli_stockphones` (
  `ID` int(11) NOT NULL,
  `StockID` int(11) NOT NULL,
  `CountryCode` varchar(4) NOT NULL,
  `Phone` varchar(11) NOT NULL,
  `IsViber` tinyint(1) NOT NULL,
  `IsWatsapp` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16;

--
-- Truncate table before insert `pli_stockphones`
--

TRUNCATE TABLE `pli_stockphones`;
--
-- Dumping data for table `pli_stockphones`
--

INSERT INTO `pli_stockphones` (`ID`, `StockID`, `CountryCode`, `Phone`, `IsViber`, `IsWatsapp`) VALUES
(55, 10, '00', '', 0, 0),
(3, 9, '00', '', 0, 0),
(4, 8, '49', '3', 0, 0),
(53, 7, '00', '', 0, 0),
(54, 7, '00', '', 0, 0);
