
-- --------------------------------------------------------

--
-- Table structure for table `pli_users`
--

DROP TABLE IF EXISTS `pli_users`;
CREATE TABLE `pli_users` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(25) NOT NULL,
  `UserPsw` varchar(254) NOT NULL,
  `UserEmail` varchar(50) NOT NULL,
  `UserPlan` int(11) NOT NULL,
  `Active` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16;

--
-- Truncate table before insert `pli_users`
--

TRUNCATE TABLE `pli_users`;
--
-- Dumping data for table `pli_users`
--

INSERT INTO `pli_users` (`UserID`, `UserName`, `UserPsw`, `UserEmail`, `UserPlan`, `Active`) VALUES
(20, 'Имя 1', 'c4ca4238a0b923820dcc509a6f75849b', '1@mail.ru', 1, 0),
(21, 'Имя2', 'c81e728d9d4c2f636f067f89cc14862c', '2@mail.ru', 1, 1),
(22, 'Тест-1', '098f6bcd4621d373cade4e832627b4f6', 'test@ukr.net', 1, 1);
