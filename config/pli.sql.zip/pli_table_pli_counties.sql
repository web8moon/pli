
-- --------------------------------------------------------

--
-- Table structure for table `pli_counties`
--

DROP TABLE IF EXISTS `pli_counties`;
CREATE TABLE `pli_counties` (
  `ID` int(11) NOT NULL,
  `Name` varchar(12) CHARACTER SET utf8 NOT NULL,
  `COU_IS_GROUP` int(11) NOT NULL,
  `DefaultCurrency` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16;

--
-- Truncate table before insert `pli_counties`
--

TRUNCATE TABLE `pli_counties`;
--
-- Dumping data for table `pli_counties`
--

INSERT INTO `pli_counties` (`ID`, `Name`, `COU_IS_GROUP`, `DefaultCurrency`) VALUES
(225, 'Україна', 0, 1),
(187, 'Россия', 0, 2),
(158, 'Poland', 0, 5),
(52, 'Deutschland', 0, 3);
